
'use client';

import React from 'react';


export default function LegalPage() {


    return (
        <div className="container mx-auto px-4 py-8">
            Select document on the left.
        </div>
    );
}