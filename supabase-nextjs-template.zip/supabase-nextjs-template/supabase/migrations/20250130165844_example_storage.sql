insert into storage.buckets
  (id, name, public)
values
  ('files', 'files', false);